const firebaseConfig = {
  apiKey: "AIzaSyCqFzfUAZbbA0nIB6OHZwsrEbLgMpY37YI",
  authDomain: "mahrusul-58273.firebaseapp.com",
  databaseURL: "https://mahrusul-58273-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "mahrusul-58273",
  storageBucket: "mahrusul-58273.firebasestorage.app", 
  messagingSenderId: "309979444745",
  appId: "1:309979444745:web:5347165f9b7896622b2ad8",
  measurementId: "G-N23XRD22Z2"
};
let app;
if (!firebase.apps.length) { 
  app = firebase.initializeApp(firebaseConfig);
} else {
  app = firebase.app(); 
}
const db = firebase.database(app); 
export { app, db };